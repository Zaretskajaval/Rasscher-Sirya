﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RaschetSyrya
{
    internal class Program
    {
        static void Main(string[] args)
        {
            WSUniversalLib.MaterialCalculator calculator = new WSUniversalLib.MaterialCalculator();

            // Вызываем метод CalculateMaterial для расчета необходимого количества сырья
            int materialNeeded = calculator.CalculateMaterial(15, 20, 45, "Тип продукции 3", "Тип материала 1");

            if (materialNeeded != -1)
            {
                Console.WriteLine($"Необходимое количество сырья: {materialNeeded}");
            }
            else
            {
                Console.WriteLine("Ошибка: Неправильные параметры для расчета.");
            }
            Console.ReadKey();
        }
    }
}
