﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RaschetSyrya.WSUniversalLib
{
    public class MaterialCalculator
    {
        public int CalculateMaterial(int count, double width, double length, string productType, string materialType)
        {
            // Площадь продукции
            double area = width * length;

            // Коэффициент типа продукции
            double productCoefficient;
            switch (productType)
            {
                case "Тип продукции 1":
                    productCoefficient = 1.1;
                    break;
                case "Тип продукции 2":
                    productCoefficient = 2.5;
                    break;
                case "Тип продукции 3":
                    productCoefficient = 8.43;
                    break;
                default:
                    // Несуществующий тип продукции
                    return -1;
            }

            // Процент брака материала в зависимости от его типа
            double materialWaste;
            switch (materialType)
            {
                case "Тип материала 1":
                    materialWaste = 0.003; // 0.3%
                    break;
                case "Тип материала 2":
                    materialWaste = 0.0012; // 0.12%
                    break;
                default:
                    // Несуществующий тип материала
                    return -1;
            }

            // Количество сырья без учета брака
            double rawMaterial = count * area * productCoefficient;

            // Учитываем брак материалов
            double totalMaterial = rawMaterial / (1 - materialWaste);

            // Округляем до ближайшего большего целого
            int roundedMaterial = (int)Math.Ceiling(totalMaterial);

            return roundedMaterial;
        }
    }
}

